/*
 * ============================================================================
 * render.js — LAYER 2 OF 5. State goes in. The screen comes out.
 *
 * THE STARTER. What is marked CODE HERE is yours; everything else is given.
 *
 * NOTHING IN THIS FILE KNOWS THAT ANYTHING IS BEING SAVED, AND NOTHING IN IT MAY LEARN
 * THAT THERE IS A NETWORK. Search it when you are finished for `localStorage`, `JSON`,
 * `fetch`, `await` and `http` — all five must find nothing. You draw one new region
 * today and that region is about a REQUEST, which is the most temporal thing in the
 * application; it is still drawn from a plain object, synchronously, the same way a
 * list of six groceries is.
 *
 * THERE IS NO `async` IN THIS FILE AND THERE MUST NOT BE. A painter that awaits is a
 * painter that can be halfway through when the next state arrives, and two half-painted
 * screens on top of each other is a bug with no reproduction steps. Everything that
 * waits waits in events.js; by the time `render` runs, the answer is already a fact.
 *
 * The prohibitions are unchanged. Nothing here changes state, registers a listener,
 * or reads the DOM to decide what to draw.
 *
 * TWO DOCUMENTED EXCEPTIONS IN THE WHOLE APPLICATION, and they are the same exception
 * twice: a browser control is handed back a value it owns.
 *   1. `renderFilters` reads the <select>'s value before rebuilding its options and
 *      puts it back afterwards (week 10).
 *   2. The add/edit form's FIELDS are not drawn from state at all — they are filled by
 *      events.js when editing starts, and read by events.js on submit. What IS drawn
 *      from state is the form's MODE: which button label, whether "cancel" is offered,
 *      and which row is marked. See `renderFormMode` below, and the header of
 *      events.js for why the fields themselves cannot be in the loop.
 * ============================================================================
 */
import {
  selectCategories,
  selectEditing,
  selectNewSuggestions,
  selectOne,
  selectSearchView,
  selectSummary,
  selectVisible,
} from './state.js';

/**
 * Build ONE row and return it, unattached. A COMPONENT: item in, element out.
 *
 * `data-id`, never `data-index`. Unchanged from week 10, and this week it earns its
 * keep twice more: an id is what the edit button carries, and an id is what survives
 * `JSON.stringify` and comes back meaning the same thing. An array position does not
 * survive a sort, let alone a reload.
 *
 * @param {{ id: string, title: string, number: number, category: string, created: string }} item
 * @param {string | null} editingId  which row is open in the form, so it can be marked
 * @returns {HTMLLIElement}
 */
export function itemRow(item, editingId = null) {
  const li = document.createElement('li');
  li.dataset.id = item.id;
  li.className =
    'flex flex-wrap items-center gap-3 rounded-lg border p-4 ' +
    (item.id === editingId ? 'border-brand bg-panel' : 'border-line');

  const title = document.createElement('a');
  title.className = 'item-title flex-1 font-semibold text-brand underline underline-offset-4';
  title.href = `item.html?id=${encodeURIComponent(item.id)}`;
  title.textContent = item.title;

  const category = document.createElement('span');
  category.className = 'item-category rounded-md bg-panel px-2 py-1 text-sm text-muted';
  category.textContent = item.category;

  const number = document.createElement('span');
  number.className = 'item-number w-10 text-center text-sm text-muted';
  number.textContent = item.number;

  li.append(title, category, number);

  for (const [cls, label, aria] of [
    ['plus', '+1', `הוסף אחד ל${item.title}`],
    ['edit', 'ערוך', `ערוך את ${item.title}`],
    ['remove', 'הסר', `הסר את ${item.title}`],
  ]) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className =
      `${cls} rounded-md border border-line px-3 py-1 text-sm ` +
      'focus-visible:outline-2 focus-visible:outline-offset-2 ' +
      (cls === 'remove' ? 'hover:border-bad hover:text-bad' : 'hover:border-brand');
    /* A <span> inside the button, so `event.target` is usually NOT the button itself.
       The delegated handler is written for that, which is the only way it stays
       correct when somebody later puts an icon in here. */
    const text = document.createElement('span');
    text.textContent = label;
    button.append(text);
    button.setAttribute('aria-label', aria);
    li.append(button);
  }

  return li;
}

/** The list, its counter and its two empty states. */
function renderList(state) {
  const list = document.querySelector('#list');
  if (!list) return;

  const visible = selectVisible(state);

  list.replaceChildren(...visible.map((item) => itemRow(item, state.editingId)));
  document.querySelector('#count').textContent = visible.length;

  /* Two empty states, not one, and the sentence says which — because "there is
     nothing here" sends the user to the add form and "nothing matched" sends them to
     the search box. From this week there is a third thing an empty pantry can mean,
     and the wording has to survive it: an empty collection that was SAVED empty is
     not a fresh start, and telling a user who just deleted everything to "add your
     first item" is at least not a lie. */
  const empty = document.querySelector('#empty');
  const nothingAtAll = state.items.length === 0;
  empty.hidden = visible.length > 0;
  empty.querySelector('span').textContent = nothingAtAll
    ? 'אין כאן כלום. הוסף פריט בטופס שלמעלה.'
    : 'שום פריט לא מתאים לחיפוש ולסינון הנוכחיים.';

  /* The offer to load the demo data belongs to the first of the two empty states
     only. Offering it to somebody whose search matched nothing would put six sample
     items into a collection they are searching. */
  document.querySelector('#reset-demo').hidden = !nothingAtAll;
}

/**
 * The form's MODE — not its fields. See the file header.
 *
 * Three things, all derived from one nullable field: what the submit button says,
 * whether there is a way out, and a sentence naming what is being edited. A user who
 * clicked "ערוך" and then scrolled has no other way to find out why "הוסף" now
 * replaces something.
 */
function renderFormMode(state) {
  const submit = document.querySelector('#form-submit');
  if (!submit) return;

  const editing = selectEditing(state);

  submit.textContent = editing === null ? 'הוסף' : 'שמור';
  document.querySelector('#form-cancel').hidden = editing === null;
  document.querySelector('#form-mode').textContent =
    editing === null ? '' : `עורך את "${editing.title}"`;
}

/**
 * A sentence when a read or a write went wrong, and nothing at all when neither did.
 *
 * THE POINT OF WRAPPING EVERY ACCESS IS THIS ELEMENT. A `try { … } catch {}` with an
 * empty body gives the user an application that looks exactly like one that is saving
 * and is not, and they find out when they close the tab. The sentence itself is
 * written in storage.js, where the failure is understood; `render` only shows it.
 */
function renderStorageNote(state) {
  const note = document.querySelector('#storage-note');
  if (!note) return;
  note.hidden = state.storageNote === null;
  note.textContent = state.storageNote ?? '';
}

/**
 * CODE HERE — build ONE suggestion row and return it, unattached.
 *
 * A COMPONENT, exactly like `itemRow` above — and the fact that its data arrived over a
 * network changes nothing about how it is drawn, which is the point.
 *
 * It needs, at minimum:
 *   · `li.dataset.title` — the row's identity, and what the delegated handler reads.
 *     A title rather than an id because the catalogue has no ids of its own, and it is
 *     the honest key here: two suggestions with the same title ARE the same suggestion.
 *   · `<span class="suggestion-title">` with the name
 *   · `<button class="adopt">` to add it to the collection
 *   · the sentence, if there is one, in `<p class="suggestion-note">`
 *
 * `textContent`, on a string that came off the internet and has been through nobody's
 * review. Week 9's rule has not moved, and this is the week it stops being theoretical:
 * with `innerHTML` here, whoever can edit that page can run code in yours.
 *
 * If you render a link to the source, `target="_blank"` needs `rel="noopener"` — week 1.
 *
 * @param {{ title: string, note: string, url: string }} suggestion
 * @returns {HTMLLIElement}
 */
export function suggestionRow(suggestion) {
  // CODE HERE
  return document.createElement('li');
}

/**
 * CODE HERE — THE SEARCH PANEL. Five views, and exactly one of them at a time.
 *
 * ── THE ONE ATTRIBUTE THAT MAKES THIS GRADEABLE, AND DEBUGGABLE
 *
 * `#api-panel` must carry `data-state`, and it must always carry exactly one of the
 * five words `idle` `loading` `empty` `error` `results`. Open the Elements tab, type in
 * the box, and watch it change. Your CI and the grader read that attribute and nothing
 * else — which is what lets thirty different APIs be graded by one check.
 *
 * ── WHY ONE ATTRIBUTE AND NOT FIVE BOOLEANS ON FIVE ELEMENTS
 *
 * Because five booleans can be in thirty-two combinations and only five of them mean
 * anything. The classic report — "it shows the spinner AND says nothing was found" — is
 * one of the other twenty-seven. Compute the view ONCE with `selectSearchView`, then
 * hide or show each region FROM that one value rather than each from its own condition.
 *
 * What it has to do:
 *   1. `panel.dataset.state = selectSearchView(state)`
 *   2. `hidden` on `#api-idle`, `#api-loading`, `#api-empty` and `#api-error`, all four
 *      from that same value
 *   3. the sentence into `#api-error-text`, and the searched-for term into
 *      `#api-empty-term`
 *   4. `#api-retry` shown only when trying again could plausibly help — a timeout or a
 *      network failure, never a status. Asking a 500 the same question gets the same
 *      answer.
 *   5. the rows into `#api-results`, from `selectNewSuggestions(state)`
 *   6. `#api-source` — shown only when the LOCAL catalogue answered. "We searched the
 *      internet" is the default assumption and does not need saying; "this came from a
 *      copy that was frozen in August" absolutely does.
 */
function renderSearch(state) {
  // CODE HERE
}

/** The shelf filter, whose options are derived from the collection. */
function renderFilters(state) {
  const select = document.querySelector('#category');
  if (!select) return;

  /* EXCEPTION 1. See the file header. */
  const chosen = select.value;

  const all = document.createElement('option');
  all.value = 'all';
  all.textContent = 'הכול';

  select.replaceChildren(
    all,
    ...selectCategories(state).map((category) => {
      const option = document.createElement('option');
      option.value = category;
      option.textContent = category;
      return option;
    }),
  );

  select.value = chosen;
  if (select.value === '') select.value = 'all';
}

/** The detail page. */
function renderDetail(state) {
  const mount = document.querySelector('#detail');
  if (!mount) return;

  const id = new URLSearchParams(location.search).get('id');
  const item = selectOne(state, id);

  const heading = document.createElement('h1');
  heading.className = 'text-2xl font-bold';

  if (item === null) {
    heading.textContent = 'הפריט לא נמצא';
    const explain = document.createElement('p');
    explain.className = 'mt-2 text-muted';
    explain.textContent =
      id === null
        ? 'הגעת לעמוד הזה בלי מזהה. בחר פריט מהרשימה.'
        : `אין במזווה פריט עם המזהה "${id}". ייתכן שהוא הוסר.`;
    mount.replaceChildren(heading, explain);
    document.title = 'המזווה — הפריט לא נמצא';
    return;
  }

  heading.textContent = item.title;

  const facts = document.createElement('dl');
  facts.className = 'mt-6 grid gap-3 rounded-lg border border-line bg-panel p-4 sm:grid-cols-2';
  for (const [label, value] of [
    ['מדף', item.category],
    ['כמות', item.number],
    /*
     * THE DATE, AND IT IS A STRING.
     *
     * `item.created` is an ISO 8601 string and never a `Date`, because a `Date` does
     * not survive the round trip: `JSON.stringify` turns it into exactly this string
     * (via `Date.prototype.toJSON`) and `JSON.parse` has no idea it was ever anything
     * else. An application that keeps `Date` objects in state works perfectly until
     * the first reload and then throws `created.getFullYear is not a function` from
     * inside `render` — which is the last place anybody looks for a storage bug.
     *
     * The rule: STORE THE STRING, CONVERT AT THE POINT OF USE. It is one line here
     * and there is no way to forget it.
     */
    ['נוסף', new Date(item.created).toLocaleDateString('he-IL')],
  ]) {
    const wrap = document.createElement('div');
    const dt = document.createElement('dt');
    dt.className = 'text-sm text-muted';
    dt.textContent = label;
    const dd = document.createElement('dd');
    dd.className = 'font-semibold';
    dd.textContent = value;
    wrap.append(dt, dd);
    facts.append(wrap);
  }

  mount.replaceChildren(heading, facts);

  /*
   * CODE HERE (part ה) — the enrichment.
   *
   * `note` and `source` are on an item only if it came from the catalogue; the six seed
   * groceries were typed and have neither. So the test is PRESENCE, not source — this
   * file has no idea a network exists and must not start caring now.
   *
   * When you have written it, notice that it reads exactly like the two rows above it.
   * Something asynchronous, cancellable and capable of failing became, by the time it
   * reached here, a string on an object.
   */

  document.title = `המזווה — ${item.title}`;
}

/** The summary page. */
function renderSummary(state) {
  const total = document.querySelector('#summary-count');
  if (!total) return;

  const summary = selectSummary(state);
  total.textContent = summary.total;
  document.querySelector('#summary-extra').textContent = summary.extra;

  document.querySelector('#summary-shelves').replaceChildren(
    ...summary.byCategory.map(({ category, count }) => {
      const li = document.createElement('li');
      li.className = 'flex items-center justify-between rounded-lg border border-line p-3';
      li.dataset.category = category;

      const name = document.createElement('span');
      name.className = 'shelf-name font-semibold';
      name.textContent = category;

      const value = document.createElement('span');
      value.className = 'shelf-count text-muted';
      value.textContent = count;

      li.append(name, value);
      return li;
    }),
  );
}

/**
 * THE render function. One entry point, called on every state change, for every page.
 *
 * One more region than week 10 and not one line of new plumbing: each returns
 * immediately when its mount is absent, so the detail page and the summary page are
 * unaffected by a search panel they do not have.
 *
 * IT IS STILL SYNCHRONOUS AND IT IS STILL CALLED THE SAME WAY. Nothing about adding a
 * network changed how the screen is produced — which is worth saying out loud, because
 * "I need to await something in render" is the first instinct and it is always the
 * wrong one. The waiting happened in events.js; by the time this runs, the answer is
 * in `state` and it is as ordinary as everything else there.
 */
export function render(state) {
  renderFilters(state);
  renderList(state);
  renderFormMode(state);
  renderStorageNote(state);
  renderSearch(state);
  renderDetail(state);
  renderSummary(state);
}
